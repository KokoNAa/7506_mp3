# DASE7506 MP3 · SQL Repair Agent report

## Agent loop

The agent first checks the exact original SQL, then requests the official
cached repair hints and schema. It builds a candidate queue from the draft
and hints using SQLGlot to parse SQLite SQL. Candidate edits include
identifier binding and join repair, projection alignment, aggregation,
comparison operators, grouping, and ordering. The implementation tracks
checked candidates, prior errors, and equivalent SQL forms within each
episode. It prioritizes repairs suggested by tool errors, such as unknown
columns, and uses mismatched public results to change later candidates.

If the checked candidates provide weak evidence, the agent can spend up to
two local Qwen completions on rewrites. When none matches the example, the
rewriter receives short declared foreign-key paths and possible source tables
for the output fields. The schema and recent checks are compacted for the
model. A fixed-size context records column names, relevant schema relations,
the public example and a few SQL attempts. All generated SQL must pass the
official `check` interface before it can be selected. The final ranker favors
candidates that match the public example. It combines Qwen candidate-letter
logits, general SQL and question features, and a preference score fitted on
official training labels. It evaluates the same candidates in two orders to
reduce position bias. With no public match, a deterministic fallback selects
among checked queries.

Episode state is reset for each task. The cached hints come from the official
`repair_hint` tool. The submitted configuration leaves example retrieval
disabled and does not load a separate search index or answer store.

## Evaluation and controlled ablations

| Evaluation | Correct tasks | Accuracy |
| --- | ---: | ---: |
| CUDA validation | 106/120 | 88.33% |
| Official Linux CPU test | 196/240 | 81.67% |

Correctness requires the final SQL to pass all three official grading
instances. Test predictions and the unchanged scorer output are
`outputs/test.json` and `outputs/test-score.json`. The scorer replayed
the tool history. An independent rescoring of that prediction file on
Linux reproduced all per-task and per-instance decisions.

| Controlled validation experiment | Configuration change | Correct |
| --- | --- | ---: |
| Frozen candidate search and ranker | Reference condition | 106/120 |
| Foreign-key guidance ablation | Remove declared paths and field-source context from rewrite prompts | 104/120 |
| Rule-score ablation | Set the rule-score weight from 2.5 to zero | 104/120 |
| Training-prior ablation | Set the trained-prior weight from 2.5 to zero | 104/120 |

The foreign-key ablation uses a separate CUDA rollout with the same adapter
and ranking weights. The correct checked candidate coverage was 110/120
with guidance and 107/120 without it. The two ranker ablations keep the
exact same validation tool trajectories and candidate scores. Each alternate
selection was replayed and scored with the official framework. Validation
was used for configuration selection before the frozen CPU test.

### Failure cases

The final SQL matched the public example in 30 of the 44 failed test tasks.
These errors illustrate how a join, filter, or aggregation can appear
correct on one instance yet differ on another. The other 14 failed tasks
had a final query whose public result already differed from the expected
example. On validation, 10 tasks had no candidate that passed all three
instances, and 4 other tasks had such a candidate but selected a different
query. Those two groups separate candidate coverage from final selection.

### CPU resources

| Measure | Verified result |
| --- | ---: |
| Prediction wall time | 962.7 s |
| Prediction CPU time, user plus system | 3705.7 s |
| Peak prediction RSS | 4.86 GiB |
| Scoring wall time | 10.7 s |
| Scoring CPU time, user plus system | 41.7 s |
| Mean and maximum charged tools per task | 6.55 and 8 |
| Total and maximum local model calls | 458 and 4 per task |
| Maximum newly generated tokens per model call | 192 |

Prediction used one worker, four CPU threads, and PyTorch 2.7.1+cu126
executing on CPU. Model-call records in `outputs/test-calls.jsonl`
contain prompts, generated text, token counts, and model/adapter identity.

## Prompt-injection risks and safeguards

Questions, result previews, error messages and hint SQL are untrusted inputs.
They could contain text that tells the model to ignore the question, emit a
different output format or change the query purpose. The prompt places
these fields in serialized JSON, escapes chat-control markers, and asks the
model to treat the payload as data. Retrieved examples are disabled in the
frozen configuration. The ranker is restricted to existing checked
candidate letters. Rewriter text is parsed as a candidate SQL statement and
passed through the official read-only executor. The controller selects tool
actions and enforces the checking and generation limits. A misleading
payload can still reduce query correctness.

## Model and data provenance

- Base model `Qwen/Qwen3-0.6B` at immutable revision
  `c1899de289a04d12100db370d81485cdf75e47ca`.
- One unmerged rank-16 LoRA, with 10,092,544 trainable A/B parameters.
  The combined model has 606,142,464 parameters. The base model and
  tokenizer were frozen. Loading is local-only with safetensors and remote
  code disabled.
- The joint stage used 480 official train rewrites and 102 checked ranking
  records. The curriculum stage used 1,348 repair or synthesis records
  derived from the same 480 training tasks and 102 ranking records. The
  final stage used 159 ranking records, including 57 obtained by scoring
  actual model-written training candidates, and replayed 430 curriculum
  rewrites. Training used BF16 on an NVIDIA L40. Training inputs were
  checked against the official train IDs and the input hashes in the logs.
- The ranking prior was fitted on the training records. All data-generation
  scripts and training configurations are included. Test references and
  extra database instances were used by the official scorer.
- OpenAI Codex assisted with implementation, experiment orchestration,
  auditing, and report preparation. During scoring, all live model calls
  used the declared offline Qwen model and its LoRA.

## Reproduce

Use the official v3 starter package from the course page and Python 3.12.
Follow the pinned model download and installation commands in `README.md`,
using this export as `PROJECT`. Extract the separate LoRA ZIP into
`$MP3_ADAPTER_DIR`. Its model-file SHA-256 is
`1a09a5691f5cbee9375b781b296a2a7096f84c4d7701a014c364152de0e6b64c`.

```bash
export MP3_MODEL_DEVICE=cpu
export CUDA_VISIBLE_DEVICES=""
bash "$PROJECT/experiments/run_variant.sh" "$STARTER" "$PROJECT/reproduction" \
  "$PROJECT/submission/final.json" test test
```

The same command with `validation validation` runs the validation split.
The experiment table uses Linux CUDA BF16 for validation and Linux CPU
FP32 for the submitted test score.
